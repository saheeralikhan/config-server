import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {  Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  
  constructor(private http : HttpClient) { }

  ngOnInit(): void {   
   
  }

  getConfigData(): Observable <any> {     
    return this.http.get('http://localhost:8080/config');       
  }

  getSearchData(keyword : string): Observable <any> {     
    return this.http.get('http://localhost:8080/grep?search_key='+ keyword);       
  }
}