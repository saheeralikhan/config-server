import { Component, Input, Output } from '@angular/core';
import { WebSocketService } from '../web-socket.service';

@Component({
  selector: 'app-live-log',
  templateUrl: './live-log.component.html',
  styleUrls: ['./live-log.component.css']
})
export class LiveLogComponent {

  @Input()
  logFormData: any ;

  @Output()
  liveData: String[] = [];

  constructor (public webSocketService : WebSocketService){
    this.getLiveData(this.logFormData);
  }
  
  ngOnInit(): void { 
    this.getLiveData(this.logFormData);
   }

   getLiveData (logFormData : any){

   let data = this.webSocketService.getLiveData()
   .subscribe(
    (data : any) =>{ 
      this.liveData.push(data.trim().toString());
    }); 
  }
}
