import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchLogResultComponent } from './search-log-result.component';

describe('SearchLogResultComponent', () => {
  let component: SearchLogResultComponent;
  let fixture: ComponentFixture<SearchLogResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchLogResultComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchLogResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
