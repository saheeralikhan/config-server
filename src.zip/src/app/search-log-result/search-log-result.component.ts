import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { LogService } from '../log.service';
import { WebSocketService } from '../web-socket.service';
import { MatAccordion } from '@angular/material/expansion';


@Component({
  selector: 'app-search-log-result',
  templateUrl: './search-log-result.component.html',
  styleUrls: ['./search-log-result.component.css']
})

export class SearchLogResultComponent implements OnInit {

  @Input()
  logFormData: any;

  @ViewChild(MatAccordion) accordion: MatAccordion = new MatAccordion;

  configData: any;
  searchData: string[] = [];

  constructor(public logService: LogService, public webSocketService: WebSocketService) { }

  ngOnInit(): void { }

  LogSearchRequestForm = new FormGroup({
    serverName: new FormControl(),
    projName: new FormControl(),
    projInstance: new FormControl(),
    startDate: new FormControl(),
    endDate: new FormControl(),
    searchKeyword: new FormControl(),
  });
  logData: any;

  onSearch(): void {
    debugger
    //   this.webSocketService.getSearchData()
    //     .subscribe(
    //       data => {
    //         this.logData = data;
    //       });
    // }
    //"http://localhost:8080/grep?search_key=ArithmeticException"
    this.logService.getSearchData(this.LogSearchRequestForm.value.searchKeyword).subscribe(
      () => {
        //if(searchStatus == "Success"){
        this.webSocketService.getSearchData()
          .subscribe(
            (data: any) => {
              this.searchData.push(data.trim().toString());
            });
         // }
      });
  }
}