import { Injectable } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';

@Injectable()
export class LogSearchRequest implements ControlValueAccessor{
    writeValue(obj: any): void {
      throw new Error('Method not implemented.');
    }
    registerOnChange(fn: any): void {
      throw new Error('Method not implemented.');
    }
    registerOnTouched(fn: any): void {
      throw new Error('Method not implemented.');
    }
    /*public serverName = new String>('');
    public envName = new String>('');
    public projName  = new String>('');
    public projInstance  = new String>('');
    public startDate  = new Date>(new Date());
    public endDate  = new Date>(new Date());
    public searchKeyword  = new String>('');*/

    public serverName : String = '';
    public envName : String = '';
    public projName : String = '';
    public projInstance : String = '';
    public startDate  : Date = new Date();
    public endDate  : Date = new Date();
    public searchKeyword : String = '';

    public LogSearchRequest(serverName: String, envName: String, projName : String,
                             projInstance : String, startDate : Date, 
                             endDate : Date ,searchKeyword : String) {
        this.serverName = serverName;
        this.envName = envName;
        this.projName = projName;
        this.projInstance = projInstance;
        this.startDate = startDate;
        this.endDate = endDate;
        this.searchKeyword = searchKeyword;
    }

    public setServerName (serverName: String) : void{
      this.serverName = serverName;
    }

    public setProjName (projName: String) : void{
      this.projName = projName;
    }

    public setProjInstance (projInstance: String) : void{
      this.projInstance = projInstance;
    }

    public setStartDate (startDate: Date) : void{
      this.startDate = startDate;
    }

    public setEndDate (endDate: Date) : void{
      this.endDate = endDate;
    }

    public setSearchKeyword (searchKeyword: String) : void{
      this.searchKeyword = searchKeyword;
    }
  }