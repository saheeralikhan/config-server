import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './include/header/header.component';
import { LiveLogComponent } from './live-log/live-log.component';
import { SearchLogResultComponent } from './search-log-result/search-log-result.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LogSearchRequest } from './model/LogSearchRequest';
import { FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LogService } from './log.service';
import {MaterialModule} from './material-module';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LiveLogComponent,
    SearchLogResultComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [LogSearchRequest,
    LogService,
    
    // {
    //   provide: NG_VALUE_ACCESSOR,
    //   useValue: new LogSearchRequest().serverName,
    //   multi: true
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
