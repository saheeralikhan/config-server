import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { LogService } from './log.service';
import { LogSearchRequest } from './model/LogSearchRequest';
import { WebSocketService } from './web-socket.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'logAggregator';

  serverList : any[] = [];
  projectList: any[] = [];
  projectInstAvl: any[] = [];
  configData: any;
  displayBelowItem : boolean = false;
  public logSearchRequest = new LogSearchRequest();
  logData: any;

  LogRequestForm = new FormGroup({
    serverName: new FormControl(),
    projName: new FormControl(),
    projInstance: new FormControl(),
    startDate: new FormControl(),
    endDate: new FormControl(),
    searchKeyword: new FormControl(),
  }); 

  constructor (public logService : LogService,  public webSocketService : WebSocketService){

  }

  ngOnInit(): void {    
    this.logService.getConfigData()
    .subscribe(data => {
      this.configData = data;
      this.serverList = this.configData.servers;
    });      
  }

  changeServer = (ip : string) =>  {
    this.configData.servers.forEach((server: { ip: string; projects : Array<object> }) => {
      if(ip === server.ip){
        this.logSearchRequest.setServerName(server.ip); 
        this.projectList = server.projects;       
      } 
    });
  }

  changeProject = (projectName : string) =>  {
    this.projectList.forEach((project: { projectName: string; instanceAvl : Array<object> }) => {
      if(projectName === project.projectName){
        this.logSearchRequest.setServerName(project.projectName); 
        this.projectInstAvl = project.instanceAvl;       
      } 
    });
  }

  onGo(): void {
    if(this.LogRequestForm.valid){
      console.log(this.LogRequestForm.value); 
      this.displayBelowItem = true;

      //this.webSocketService.getLiveData(this.LogRequestForm.value);
      
      // this.logService.getSearchData(this.LogRequestForm.value.searchKeyword)
      //     .subscribe(
      //       data => {
      //       this.logData = data;
      //       console.log(data);
      //     });          
    }    
  }  
}