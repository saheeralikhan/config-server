import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  logData: any;

  constructor() { }

  ngOnInit(){
    this.socket$.subscribe(console.log);
    this.socketSearch.subscribe(console.log);
    this.getLiveData();
  }
    private socket$ : WebSocketSubject<any>= webSocket({
      url: 'ws://localhost:8080/logs',
       openObserver: {
        next: (data : any) => {
          console.log('Connection live ok', data);
        }
      },
      closeObserver: {
        next() {
          const customError = { code: 6666, reason: 'Custom evil reason' }
          console.log(`code: ${ customError.code }, reason: ${ customError.reason }`);
        }
      },
      //Apply any transformation of your choice.
      deserializer: ({ data }) => data
    });
    

    private socketSearch : WebSocketSubject<any>= webSocket({
     url: 'ws://localhost:8080/search',
      openObserver: {
        next: (data : any) => {
          console.log('Connection search ok', data);
        }
      },
      closeObserver: {
        next() {
          const customError = { code: 6666, reason: 'Custom evil reason' }
          console.log(`code: ${ customError.code }, reason: ${ customError.reason }`);
        }
      },
      //Apply any transformation of your choice.
      deserializer: ({ data }) => data
    });
  
   getLiveData () {
     return this.socket$;      
    } 
    
    getSearchData(){
      return this.socketSearch;
    }
}
