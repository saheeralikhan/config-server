import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LiveLogComponent } from './live-log/live-log.component';
import { SearchLogResultComponent } from './search-log-result/search-log-result.component';

const routes: Routes = [
  {path : 'liveLogs', component : LiveLogComponent},
  {path : 'searchLogs', component : SearchLogResultComponent},
  //{path : '**', redirectTo : 'searchLogs'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
